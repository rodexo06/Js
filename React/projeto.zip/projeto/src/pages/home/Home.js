import React, { Component } from 'react'

class Home extends Component {
  render() {
    return (
        <div>
            Página inicial
        </div>
    );
  }
}

export default Home;